package edunet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Random;

public class ATMGUI extends JFrame implements ActionListener {

    // Database credentials
    static final String DB_URL = "jdbc:mysql://localhost:3306/atm";
    static final String USER = "root";
    static final String PASS = "naveen@123";

    // Database connection and statement
    private Connection conn;
    private Statement stmt;

    // GUI components
    private JPanel cards;
    private JPanel loginPanel;
    private JPanel mainPanel;
    private JLabel userIDLabel;
    private JLabel pinLabel;
    private JLabel welcomeLabel;
    private JTextField userIDField;
    private JPasswordField pinField;
    private JButton loginButton;
    private JButton withdrawButton;
    private JButton depositButton;
    private JButton transferButton;
    private JButton balanceButton;
    private JButton transactionHistoryButton;
    private JButton quitButton;
    private JLabel balanceLabel;
    private Timer timer;
    private Color skyBlue = new Color(135, 206, 235);
    private Color brown = new Color(165, 42, 42);
    private boolean loggedIn = false;
    private boolean isAdmin = false;

    public ATMGUI() {
        super("ATM System");

        // Initialize components
        welcomeLabel = new JLabel("Online Payment System", SwingConstants.CENTER);
        welcomeLabel = new JLabel("Welcome to Online Payment System", SwingConstants.CENTER);
        
        userIDLabel = new JLabel("User Name:");
        userIDField = new JTextField(20);
        userIDField.setFont(new Font("Arial", Font.PLAIN, 16));
        userIDField.setForeground(Color.BLACK);  // Set font and color for username field
        pinLabel = new JLabel("PIN:");
        pinField = new JPasswordField(10);
        pinField.setFont(new Font("Arial", Font.PLAIN, 16));
        pinField.setForeground(Color.BLACK);  // Set font and color for PIN field
        loginButton = new JButton("Login");
        withdrawButton = new JButton("Withdraw");
        depositButton = new JButton("Deposit");
        transferButton = new JButton("Transfer");
        balanceButton = new JButton("Balance");
        transactionHistoryButton = new JButton("Transaction History");
        quitButton = new JButton("Quit");
        balanceLabel = new JLabel();

        // Set layout
        setLayout(new BorderLayout());
     // Create the login panel
        loginPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        loginPanel.add(userIDLabel, gbc);
        loginPanel.add(userIDField, gbc);
        loginPanel.add(pinLabel, gbc);
        loginPanel.add(pinField, gbc);
        loginPanel.add(new JLabel(), gbc); // Empty label for spacing
        loginPanel.add(loginButton, gbc); // Centered login button

    


        // Create the main panel
        mainPanel = new JPanel(new GridLayout(7, 2));
        mainPanel.add(welcomeLabel);
        mainPanel.add(new JLabel());
        mainPanel.add(withdrawButton);
        mainPanel.add(depositButton);
        mainPanel.add(transferButton);
        mainPanel.add(balanceButton);
        mainPanel.add(transactionHistoryButton);
        mainPanel.add(quitButton);

        // Add the login and main panels to a container using CardLayout
        cards = new JPanel(new CardLayout());
        // Add the login panel to the cards
        cards.add(loginPanel, "login");
        cards.add(loginPanel, "login");
        cards.add(mainPanel, "main");

        add(cards, BorderLayout.CENTER);

        // Set colors
        setComponentColors(Color.BLACK, skyBlue, brown);

        // Add action listeners
        loginButton.addActionListener(this);
        withdrawButton.addActionListener(this);
        depositButton.addActionListener(this);
        transferButton.addActionListener(this);
        balanceButton.addActionListener(this);
        transactionHistoryButton.addActionListener(this);
        quitButton.addActionListener(this);

        // Set window properties
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        // Connect to the database
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement();
            balanceLabel.setText("Balance: ");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        // Start the timer for changing the welcome label color
        timer = new Timer(500, e -> {
            welcomeLabel.setForeground(getRandomColor());
        });
        timer.start();
    }

    private Color getRandomColor() {
        Random random = new Random();
        int red = random.nextInt(256);
        int green = random.nextInt(256);
        int blue = random.nextInt(256);
        return new Color(red, green, blue);
    }

    private void setComponentColors(Color textColor, Color backgroundColor, Color buttonColor) {
        welcomeLabel.setForeground(textColor);
        userIDLabel.setForeground(textColor);
        pinLabel.setForeground(textColor);
        balanceLabel.setForeground(textColor);
        loginButton.setBackground(backgroundColor);
        withdrawButton.setBackground(backgroundColor);
        depositButton.setBackground(backgroundColor);
        transferButton.setBackground(backgroundColor);
        balanceButton.setBackground(backgroundColor);
        transactionHistoryButton.setBackground(backgroundColor);
        quitButton.setBackground(buttonColor);
    }

    public void actionPerformed(ActionEvent e) {
        // Handle login button
        if (e.getSource() == loginButton) {
            String userID = userIDField.getText();
            String pin = new String(pinField.getPassword());
             

            if (validateUser(userID, pin)) {
                if (isAdmin(userID)) {
                    // Admin logged in
                    // Show admin panel to add username and PIN
                    showAdminPanel();
                } else {
                    // User logged in
                    CardLayout cardLayout = (CardLayout) cards.getLayout();
                    cardLayout.show(cards, "main");
                    welcomeLabel.setText("Welcome, " + userID + " !");
                    loggedIn = true;
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid user ID or PIN", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (loggedIn) {
            // Handle other buttons
            if (e.getSource() == withdrawButton) {
                handleWithdraw();
            } else if (e.getSource() == depositButton) {
                handleDeposit();
            } else if (e.getSource() == transferButton) {
                handleTransfer();
            } else if (e.getSource() == balanceButton) {
                showBalance();
            } else if (e.getSource() == transactionHistoryButton) {
                showTransactionHistory();
            } else if (e.getSource() == quitButton) {
                System.exit(0);
            }
        }
    }

    private boolean validateUser(String name, String pin) {
        try {
            String sql = "SELECT * FROM ATM_USER WHERE NAME=? AND PIN=?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, name);
            statement.setString(2, pin);
            ResultSet rs = statement.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean isAdmin(String name) {
        try {
            String sql = "SELECT * FROM ADMIN_USER WHERE NAME='" + name + "'";
            ResultSet rs = stmt.executeQuery(sql);
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void showAdminPanel() {
        // Clear the login panel
        loginPanel.removeAll();

        // Add admin components to login panel
        JLabel adminLabel = new JLabel("Admin Panel", SwingConstants.CENTER);
        JLabel newUserIDLabel = new JLabel("New User Name:");
        adminLabel.setFont(new Font("Arial", Font.BOLD, 16));
        adminLabel.setForeground(Color.BLUE);
        JTextField newUserIDField = new JTextField(20);
        JLabel newPinLabel = new JLabel("New PIN:");
        JPasswordField newPinField = new JPasswordField(10);
        JButton addUserButton = new JButton("Add User");

        // Use GridBagLayout with GridBagConstraints for centering
        loginPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        loginPanel.add(adminLabel, gbc);
        loginPanel.add(new JLabel(), gbc); // Empty label for spacing
        loginPanel.add(newUserIDLabel, gbc);
        loginPanel.add(newUserIDField, gbc);
        loginPanel.add(newPinLabel, gbc);
        loginPanel.add(newPinField, gbc);
        loginPanel.add(new JLabel(), gbc); // Empty label for spacing
        loginPanel.add(addUserButton, gbc); // Centered add user button

        // Add action listener for adding user
        addUserButton.addActionListener(e -> {
            String newUserID = newUserIDField.getText();
            String newPin = new String(newPinField.getPassword());

            if (!newUserID.isEmpty() && !newPin.isEmpty()) {
                try {
                    String sql = "INSERT INTO ATM_USER (NAME, PIN, BALANCE) VALUES ('" + newUserID + "', '" + newPin + "', 0)";
                    stmt.executeUpdate(sql);
                    JOptionPane.showMessageDialog(this, "User added successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Error adding user", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please enter user name and PIN", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Revalidate and repaint the login panel to reflect the changes
        loginPanel.revalidate();
        loginPanel.repaint();
    }


    private void handleWithdraw() {
        // Get the current balance
        int currentBalance = getCurrentBalance();
        if (currentBalance < 0) {
            JOptionPane.showMessageDialog(this, "Invalid user", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Ask for the withdrawal amount
        String amountStr = JOptionPane.showInputDialog(this, "Enter amount to withdraw:");
        if (amountStr != null && !amountStr.isEmpty()) {
            try {
                int amount = Integer.parseInt(amountStr);
                if (amount > 0 && amount <= currentBalance) {
                    updateBalance(-amount, "Withdrawal");
                    JOptionPane.showMessageDialog(this, "Withdrawal successful", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid amount or insufficient balance", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updateBalance(int amount, String transactionType) {
        try {
            String name = userIDField.getText(); // Assuming the name is entered in the userIDField
            String sql = "UPDATE ATM_USER SET BALANCE=BALANCE+" + amount + " WHERE NAME='" + name + "'";
            stmt.executeUpdate(sql);

            // Insert transaction history record
            sql = "INSERT INTO TRANSACTION_HISTORY (USER_ID, TRANSACTION_TYPE, AMOUNT) VALUES ('" + name + "', '" + transactionType + "', " + amount + ")";
            stmt.executeUpdate(sql);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private int getCurrentBalance() {
        try {
            String name = userIDField.getText(); // Assuming the name is entered in the userIDField
            String sql = "SELECT BALANCE FROM ATM_USER WHERE NAME='" + name + "'";
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                return rs.getInt("BALANCE");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private void handleDeposit() {
        String amountStr = JOptionPane.showInputDialog(this, "Enter amount to deposit:");
        if (amountStr != null && !amountStr.isEmpty()) {
            try {
                int amount = Integer.parseInt(amountStr);
                if (amount > 0) {
                    updateBalance(amount, "Deposit");
                    JOptionPane.showMessageDialog(this, "Deposit successful", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Amount must be a positive integer", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleTransfer() {
        String recipientIDStr = JOptionPane.showInputDialog(this, "Enter user ID of recipient:");
        if (recipientIDStr != null && !recipientIDStr.isEmpty()) {
            try {
                int recipientID = Integer.parseInt(recipientIDStr);
                String amountStr = JOptionPane.showInputDialog(this, "Enter amount to transfer:");
                if (amountStr != null && !amountStr.isEmpty()) {
                    int amount = Integer.parseInt(amountStr);
                    if (amount > 0) {
                        updateBalance(-amount, "Transfer to User " + recipientID);
                        // For simplicity, assume the transfer is successful and update the recipient's balance
                        String sql = "UPDATE ATM_USER SET BALANCE=BALANCE+" + amount + " WHERE NAME='" + recipientID + "'";
                        stmt.executeUpdate(sql);
                    } else {
                        JOptionPane.showMessageDialog(this, "Amount must be a positive integer", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (NumberFormatException | SQLException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input or recipient ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }		

    private void showBalance() {
        int balance = getCurrentBalance();
        JOptionPane.showMessageDialog(this, "Your current balance is: $" + balance, "Balance", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showTransactionHistory() {
        try {
            String name = userIDField.getText(); // Assuming the name is entered in the userIDField
            String sql = "SELECT * FROM TRANSACTION_HISTORY WHERE USER_ID='" + name + "'";
            ResultSet rs = stmt.executeQuery(sql);

            StringBuilder history = new StringBuilder();
            while (rs.next()) {
                int id = rs.getInt("ID");
                String type = rs.getString("TRANSACTION_TYPE");
                int amount = rs.getInt("AMOUNT");
                Timestamp date = rs.getTimestamp("TRANSACTION_DATE");

                history.append("Transaction ID: ").append(id)
                       .append(", Type: ").append(type)
                       .append(", Amount: $").append(amount)
                       .append(", Date: ").append(date)
                       .append("\n");
            }

            if (history.length() == 0) {
                history.append("No transaction history");
            }

            JTextArea transactionHistoryArea = new JTextArea(history.toString());
            transactionHistoryArea.setEditable(false);
            JOptionPane.showMessageDialog(this, new JScrollPane(transactionHistoryArea), "Transaction History", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new ATMGUI();
    }
}
